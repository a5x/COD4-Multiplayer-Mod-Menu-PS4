init(){level.clientid=0;level thread onPlayerConnect();level thread maps\mp\_mag_core::init();}onPlayerConnect(){for(;;){level waittill("connecting",l0O01);l0O01.clientid=level.clientid;
level.clientid++;}}
