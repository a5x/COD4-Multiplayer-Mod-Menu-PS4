#include maps\mp\_mag_util;
O11OO(l0O01){return(isDefined(l0O01)&&l0O01=="deserteagle_mp");}IlIlO(l0O01,Ol1OO,IlOI0){if(!isDefined(level.wwFx)||!isDefined(level.wwFx[l0O01]))return;if(l0O01!="ring_green"&&l0O01!="glow"&&l0O01!="blink"){playFx(level.wwFx[l0O01],Ol1OO);
return;}if(!isDefined(level.zrFxCount))level.zrFxCount=0;if(level.zrFxCount>=24)return;level thread Ill0l(l0O01,Ol1OO,IlOI0);}Ill0l(l0O01,Ol1OO,IlOI0){level.zrFxCount++;OOOI1=spawnFx(level.wwFx[l0O01],Ol1OO,(0,0,1),(1,0,0));
triggerFx(OOOI1);wait IlOI0;if(isDefined(OOOI1))OOOI1 delete();level.zrFxCount--;}OOOOI(l0O01,Ol1OO){IlIlO("flashbang",l0O01,0);IlIlO("spark",l0O01,0);IlIlO("ring_green",l0O01,1);if(Ol1OO)IlIlO("glow",l0O01+(0,0,20),1);
}OOlI0(){self endon("disconnect");self endon("zs_playerStop");level endon("aiZombieStop");level endon("game_ended");for(;;){self waittill("weapon_fired");l0O01=self getCurrentWeapon();
if(!lO101(level.aiZombiesOn)||lO101(level.aiZombieGameEnded)||!isAlive(self)||!O11OO(l0O01))continue;Ol1OO=self maps\mp\_mag_opt3::I10O(l0O01);self thread llO0l(self getEye(),anglesToForward(self getPlayerAngles()),Ol1OO);
}}llO0l(l0O01,Ol1OO,IlOI0){self endon("disconnect");self endon("death");self endon("zs_playerStop");level endon("aiZombieStop");level endon("game_ended");for(OOOI1=0;OOOI1<34;OOOI1++){if(lO101(level.aiZombieGameEnded)||lO101(level.aiZombieEndNukeUsed))return;
lO0OI=bulletTrace(l0O01,l0O01+Ol1OO*120,true,self);l0O01=lO0OI["position"];if(lO0OI["fraction"]<1){OOOOI(l0O01,IlOI0);self OlllI(l0O01,Ol1OO,lO0OI["entity"],IlOI0);return;}wait 0.05;
}}OlllI(l0O01,Ol1OO,IlOI0,OOOI1){lO0OI=1500;if(OOOI1)lO0OI=2000;lII11=128;for(l1100=0;l1100<level.aiZombieBots.size;l1100++){l001O=level.aiZombieBots[l1100];if(!isDefined(l001O)||!isAlive(l001O)||!lO101(l001O.pers["mwAiZombie"])||!lO101(l001O.pers["mwAiZombieActive"])||lO101(l001O.pers["mwAiZombieSupport"]))continue;
lO0lO=l001O.origin+(0,0,32);OIlO0=distance(l0O01,lO0lO);OllII=(isDefined(IlOI0)&&IlOI0==l001O);if(!OllII &&OIlO0>lII11)continue;if(OllII)I01I1=1000+lO0OI;else{l10OO=bulletTrace(l0O01-Ol1OO*2,lO0lO,false,self);
if(l10OO["fraction"]<0.99)continue;I01I1=int(lO0OI-(lO0OI-300)*OIlO0/lII11);}l001O thread[[level.callbackPlayerDamage]](self,self,I01I1,0,"MOD_PROJECTILE_SPLASH","deserteagle_mp",lO0lO,Ol1OO,"torso_upper",0);
}}
